export default function App() {
  return (
    <div style={{ padding: 20, textAlign: 'center' }}>
      <h1>Bienvenue sur AideScolaireTogo</h1>
      <p>L'application éducative pour les élèves du Togo</p>
    </div>
  );
}
